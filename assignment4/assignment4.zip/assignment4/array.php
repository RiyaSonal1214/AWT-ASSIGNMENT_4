<html>
<head><title>Assignmen4</title></head>
<body style="background-color: black;color: yellow;">
<center>
     <h2>
        Bill
    </h2>
     
    <form method="post" action="op.php">
        Enter the item names:<input type="text" name="names" placeholder="Enter the item names" required /><br><br>
        Enter the item price:<input type="text" name="price" placeholder="Enter the item price" required />
        <br><br>
        <input type="submit" name="submit" value="Store"/>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="reset" name="reset" value="Reset"/>
    </form>

</center>
</body>
</html>
